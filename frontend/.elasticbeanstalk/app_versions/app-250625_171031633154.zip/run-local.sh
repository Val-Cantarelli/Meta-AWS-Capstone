#!/bin/bash
unset DJANGO_ENV


API_BASE_URL=Ajustar
python manage.py runserver