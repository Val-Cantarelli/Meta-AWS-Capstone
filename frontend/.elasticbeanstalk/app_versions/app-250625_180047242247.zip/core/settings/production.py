from .base import *
import os

DEBUG = False

ALLOWED_HOSTS = ["*"]  
# "127.0.0.1", "localhost", "littlelemon-env.eba-gpgijkvt.us-east-1.elasticbeanstalk.com",".elasticbeanstalk.com"
# create and add domain
API_BASE_URL = os.environ.get("API_BASE_URL")

SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY")

STATIC_URL = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
#(optional)SESSION_EXPIRE_AT_BROWSER_CLOSE = True 